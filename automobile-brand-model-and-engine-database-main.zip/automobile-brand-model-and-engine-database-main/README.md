# automobile-brand-model-and-engine-database

## Sources and Inspiration

This project was developed with inspiration from the [automobile-models-and-specs]([https://github.com/ilyasozkurt/automobile-models-and-specs](https://github.com/ilyasozkurt/automobile-models-and-specs)) project, and some code has been taken from it. Many thanks to the original project owners.

https://github.com/ilyasozkurt/automobile-models-and-specs


#Changes

Car names cleaned up
production start and end dates added
